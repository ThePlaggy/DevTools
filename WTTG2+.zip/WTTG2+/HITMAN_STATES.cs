using System;

[Serializable]
public enum HITMAN_STATES
{
	NOT_ACTIVE,
	PENDING,
	ON_THE_HUNT
}
