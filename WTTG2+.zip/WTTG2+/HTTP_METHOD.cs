public enum HTTP_METHOD
{
	GET,
	POST,
	PUT,
	DELETE
}
