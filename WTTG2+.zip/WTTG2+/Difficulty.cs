public enum Difficulty
{
	CASUAL,
	NORMAL,
	LEET,
	NIGHTMARE,
	REDRUM
}
