public enum DeviceType
{
	COMPUTER,
	LAPTOP
}
