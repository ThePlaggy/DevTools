using System;

[Serializable]
public enum GAME_CONTROLLER
{
	ROAM,
	DESK,
	COMPUTER,
	PEEP_HOLE,
	HIDE,
	LOBBY_COMPUTER,
	BRACE,
	START,
	TRAILER,
	ENDING,
	SECRET
}
