public enum HackerModeMusicType
{
	menu,
	hack
}
