using System;
using UnityEngine.Events;

[Serializable]
public class DefinitionUnityEvent : UnityEvent<Definition>
{
}
