using System;
using UnityEngine.Events;

[Serializable]
public class HitmanSpawnDefUnityEvent : UnityEvent<HitmanSpawnDefinition>
{
}
