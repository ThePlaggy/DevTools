using UnityEngine;

public static class CustomSpriteLookUp
{
	public static Sprite remoteVPNlvl2;

	public static Sprite remoteVPNlvl3;

	public static Sprite speeditem;

	public static Sprite sulphur;

	public static Sprite router;

	public static Sprite tarotcard;

	public static Sprite WebBoostIdle;

	public static Sprite WebBoostNegative;

	public static Sprite WebBoostPositive;

	public static Sprite KeyCueIdle;

	public static Sprite KeyCueNegative;

	public static Sprite KeyCuePositive;

	public static Sprite voipmanager;

	public static Sprite adosicon;

	public static Sprite adios;

	public static Sprite locIcon;

	public static Sprite vwipeIdle;

	public static Sprite vwipeActive;

	public static Sprite NoSignal;

	public static Sprite CamHookIdle;

	public static Sprite CamHookActive;

	public static Sprite seckscamsStore;

	public static Sprite BatteryMeter0;

	public static Sprite BatteryMeter1;

	public static Sprite BatteryMeter2;

	public static Sprite BatteryMeter3;

	public static Sprite BatteryMeter4;

	public static Sprite laptopIcon;

	public static Sprite computerIcon;

	public static Sprite I_Keypad;

	public static Sprite dicidle;

	public static Sprite dicoutline;

	public static Sprite KeypadStore;

	public static Sprite botnetIdle;

	public static Sprite botnetActive;

	public static Sprite botnetStore;

	public static Sprite botnetTitle;

	public static Sprite megalock;

	public static Sprite megaunlock;

	public static Sprite doorLogIdle;

	public static Sprite doorLogActive;

	public static Sprite doorLogTitle;

	public static Sprite doorLogStore;

	public static Sprite secksCamsTitle;

	public static Sprite RouterDoc;

	public static Sprite routerDocIcon;

	public static Sprite routerDocIconActive;

	public static Sprite posterH;

	public static Sprite posterE;

	public static Sprite posterX;

	public static Texture2D rickastleymaboi;

	public static Sprite LOLpaper;

	public static Texture2D TheRealVacation;

	public static Sprite bug1;

	public static Sprite bug2;

	public static Sprite bug3;

	public static Sprite bug4;

	public static Sprite bug5;

	public static Sprite bug6;

	public static Sprite eggIcon;

	public static Sprite pumpkinIcon;

	public static Sprite giftIcon;

	public static Sprite strongflashlight;

	public static Sprite binclosed;

	public static Sprite binopened;

	public static Sprite wttg2PlusLogo;

	public static Sprite locationServicesBuyIcon;
}
