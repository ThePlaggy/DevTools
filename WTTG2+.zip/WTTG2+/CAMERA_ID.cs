using System;

[Serializable]
public enum CAMERA_ID
{
	MAIN,
	COMPUTER,
	PEEP_HOLE,
	LOBBY_COMPUTER,
	ENDING
}
