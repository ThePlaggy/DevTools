using System;

[Serializable]
public enum ENEMY_STATE
{
	IDLE,
	POILCE,
	HITMAN,
	BREATHER,
	DOLL_MAKER,
	CULT,
	LOCKED,
	BOMB_MAKER,
	TANNER,
	KIDNAPPER,
	EXECUTIONER,
	DELFALCO,
	NEWNOIR
}
