using TMPro;

public static class LookUps
{
	public static TMP_FontAsset TitleFont;
}
