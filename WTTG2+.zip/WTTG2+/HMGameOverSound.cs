public enum HMGameOverSound
{
	totalPoints,
	finalPoints,
	timeShow,
	newHighScore,
	gameOverImpact,
	gameOver
}
