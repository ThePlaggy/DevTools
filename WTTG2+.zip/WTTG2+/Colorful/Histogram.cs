using UnityEngine;

namespace Colorful;

[HelpURL("http://www.thomashourdel.com/colorful/doc/utilities/histogram.html")]
[ExecuteInEditMode]
[AddComponentMenu("Colorful FX/Utilities/Histogram")]
public class Histogram : MonoBehaviour
{
}
