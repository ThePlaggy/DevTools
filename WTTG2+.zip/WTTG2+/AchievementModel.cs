using System;

[Serializable]
public class AchievementModel
{
	public string APIName;

	public string DisplayName;

	public string Description;

	public bool Hidden;
}
