public class BehaviourManager
{
	public crossHairBehaviour CrossHairBehaviour { get; set; }

	public NotesBehaviour NotesBehaviour { get; set; }

	public AnnBehaviour AnnBehaviour { get; set; }

	public PlayerAudioBehaviour PlayerAudioBehaviour { get; set; }

	public DroneBehaviour DroneBehaviour { get; set; }

	public SourceViewerBehaviour SourceViewerBehaviour { get; set; }
}
