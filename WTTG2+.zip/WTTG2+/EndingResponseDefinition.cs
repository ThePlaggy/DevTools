using System;

[Serializable]
public class EndingResponseDefinition : Definition
{
	public string ResponseOption;

	public string ResponseAnimationTrigger;
}
