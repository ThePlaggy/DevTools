using UnityEngine;

public class DevToolsManager : MonoBehaviour
{
	[Header("If you're datamining and looking for DevTools, they have been properly removed from the game. I think I'll miss it more than any other from our team.")]
	private bool iAmLive;
}
