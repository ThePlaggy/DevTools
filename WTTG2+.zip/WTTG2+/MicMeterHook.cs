using UnityEngine;

public class MicMeterHook : MonoBehaviour
{
	private void Awake()
	{
	}

	private void OnDestroy()
	{
	}
}
