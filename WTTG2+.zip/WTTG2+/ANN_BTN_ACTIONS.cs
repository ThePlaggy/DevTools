using System;

[Serializable]
public enum ANN_BTN_ACTIONS
{
	BACK,
	FORWARD,
	REFRESH,
	BOOKMARKS,
	HOME,
	CODE
}
