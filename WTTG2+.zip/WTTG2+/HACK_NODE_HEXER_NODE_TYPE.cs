using System;

[Serializable]
public enum HACK_NODE_HEXER_NODE_TYPE
{
	DEAD,
	ALPHA,
	BETA
}
