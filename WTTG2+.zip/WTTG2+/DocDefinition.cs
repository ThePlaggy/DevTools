using System;

[Serializable]
public class DocDefinition : Definition
{
	public string Title;

	public string DocFolder;
}
