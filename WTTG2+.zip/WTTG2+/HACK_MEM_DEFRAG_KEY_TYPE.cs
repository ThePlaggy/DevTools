using System;

[Serializable]
public enum HACK_MEM_DEFRAG_KEY_TYPE
{
	ALPHA,
	NUMERIC,
	BOTH
}
