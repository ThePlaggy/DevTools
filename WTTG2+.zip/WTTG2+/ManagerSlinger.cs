public class ManagerSlinger
{
	public CursorManager CursorManager { get; set; }

	public AppManager AppManager { get; set; }

	public ProductsManager ProductsManager { get; set; }

	public WifiManager WifiManager { get; set; }

	public MotionSensorManager MotionSensorManager { get; set; }

	public RemoteVPNManager RemoteVPNManager { get; set; }

	public TenantTrackManager TenantTrackManager { get; set; }

	public PoliceScannerManager PoliceScanerManager { get; set; }

	public LOLPYDiscManager LOLPYDiscManager { get; set; }

	public TextDocManager TextDocManager { get; set; }
}
