using UnityEngine;

public class DeadInteract : MonoBehaviour
{
}
