using System;

[Serializable]
public class DeveloperData
{
	public string[] developers;
}
