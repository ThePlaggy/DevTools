using System;

[Serializable]
public enum KEY_DISCOVERY_MODES
{
	PLAIN_SIGHT,
	SOURCE_CODE,
	CLICK_TO_FILE,
	CLICK_TO_PLAIN_SIGHT
}
