public interface IDataObject
{
	int ID { get; set; }
}
