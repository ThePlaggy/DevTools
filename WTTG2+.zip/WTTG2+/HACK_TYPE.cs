using System;

[Serializable]
public enum HACK_TYPE
{
	SWEEPER,
	MEMDEFRAG,
	STACKPUSHER,
	NODEHEXER,
	DOSBLOCK,
	CLOUDGRID
}
