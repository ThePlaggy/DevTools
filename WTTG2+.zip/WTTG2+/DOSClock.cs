using UnityEngine;
using UnityEngine.UI;

public class DOSClock : MonoBehaviour
{
	public Image DOSClockImage;
}
