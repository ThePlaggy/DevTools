using UnityEngine;

public static class CustomSoundLookUp
{
	public static AudioFileDefinition party;

	public static AudioFileDefinition alarm;

	public static AudioFileDefinition beep;

	public static AudioFileDefinition failsafe;

	public static AudioFileDefinition reset;

	public static AudioFileDefinition systemFailure;

	public static AudioFileDefinition manipulator;

	public static AudioFileDefinition routerreset;

	public static AudioFileDefinition bombmaker;

	public static AudioFileDefinition bombmakertalk;

	public static AudioFileDefinition explosion;

	public static AudioFileDefinition youreuseless;

	public static AudioFileDefinition routerjammed;

	public static AudioFileDefinition timechange;

	public static AudioFileDefinition pull;

	public static AudioFileDefinition disappear;

	public static AudioFileDefinition fool;

	public static AudioFileDefinition fool2;

	public static AudioFileDefinition fool3;

	public static AudioFileDefinition kidnapperline;

	public static AudioFileDefinition kidnapperjump;

	public static AudioFileDefinition punch;

	public static AudioFileDefinition TannerJump;

	public static AudioFileDefinition NeedleInject;

	public static AudioFileDefinition HeadFloorHit;

	public static AudioFileDefinition BodyHit;

	public static AudioFileDefinition Window2;

	public static AudioFileDefinition Tanner_Laugh;

	public static AudioFileDefinition Having;

	public static AudioClip idiot_1;

	public static AudioClip comeout;

	public static AudioFileDefinition hallDoorOpenClose;

	public static AudioFileDefinition whistlingReverb;

	public static AudioFileDefinition exeJump;

	public static AudioFileDefinition exePunch1;

	public static AudioFileDefinition glyphClick;

	public static AudioFileDefinition strike;

	public static AudioFileDefinition swanKeyPress;

	public static AudioFileDefinition keyFound2;

	public static AudioFileDefinition answerPhone;

	public static AudioFileDefinition cellPhoneRing;

	public static AudioFileDefinition hangUpPhone;

	public static AudioFileDefinition breather_hearyou;

	public static AudioFileDefinition breather_seeyou;

	public static AudioFileDefinition breather_nightnight;

	public static AudioFileDefinition breather_breathe1;

	public static AudioFileDefinition breather_breathe2;

	public static AudioFileDefinition breather_gettingcloser;

	public static AudioFileDefinition breather_ifoundyou;

	public static AudioFileDefinition breather_imcomingforyou;

	public static AudioFileDefinition breather_knockknock;

	public static AudioFileDefinition breather_rhyme;

	public static AudioFileDefinition phoneVibrate;

	public static AudioFileDefinition boxNodeHoverClip;

	public static AudioFileDefinition boxNodeActiveClip;

	public static AudioFileDefinition blankNodeHoverClip;

	public static AudioFileDefinition goodNodeActiveClip;

	public static AudioFileDefinition CountDownTick1;

	public static AudioFileDefinition CountDownTick2;

	public static AudioFileDefinition ClockAlmostUp;

	public static AudioFileDefinition NodeHot;

	public static AudioFileDefinition NodeCold;

	public static AudioFileDefinition NodeActive;

	public static AudioFileDefinition ExitNodeActive;

	public static AudioFileDefinition ActionNodeClick;

	public static AudioClip hackermode;

	public static AudioFileDefinition gameOverTrigger;

	public static AudioFileDefinition gameOver;

	public static AudioFileDefinition totalPointSlide;

	public static AudioFileDefinition finalPointsImpact;

	public static AudioFileDefinition newHighScore;

	public static AudioFileDefinition timeShow;

	public static AudioClip HackerModeMenuMusic;

	public static AudioFileDefinition Selection;

	public static AudioFileDefinition Denied;

	public static AudioFileDefinition cameraSwitch;

	public static AudioFileDefinition keypad_Click;

	public static AudioFileDefinition keypad_Correct;

	public static AudioFileDefinition keypad_Unlock;

	public static AudioFileDefinition keypad_Wrong;

	public static AudioFileDefinition FireworksQuick1;

	public static AudioFileDefinition FireworksQuick2;

	public static AudioFileDefinition FireworksQuick3;

	public static AudioFileDefinition FireworksQuick4;

	public static AudioFileDefinition FireworksQuick5;

	public static AudioFileDefinition FireworksQuick6;

	public static AudioFileDefinition FireworksLong1;

	public static AudioFileDefinition FireworksMain;

	public static AudioFileDefinition InvalidInput;

	public static AudioFileDefinition ValidInput;

	public static AudioFileDefinition GamePass;

	public static AudioFileDefinition GameFail;

	public static AudioFileDefinition highLightCode;

	public static AudioFileDefinition KeyReturn;

	public static AudioFileDefinition KernelPowerUp;

	public static AudioFileDefinition wttg1_laugh;

	public static AudioFileDefinition WitchLaugh;

	public static AudioFileDefinition tadaaa;

	public static AudioClip deadsignal;

	public static AudioClip fireplace;

	public static AudioFileDefinition owl;

	public static AudioFileDefinition candyPickup;

	public static AudioFileDefinition ignited;

	public static AudioFileDefinition WoodClick;

	public static AudioFileDefinition getcalculated;

	public static AudioFileDefinition jingleBELLS;

	public static AudioFileDefinition TheRealVacation;

	public static AudioFileDefinition delfalcoChaseJump;

	public static AudioFileDefinition delfalcoChaseLine;

	public static AudioFileDefinition delfalcoChaseJumpB;

	public static AudioFileDefinition delfalcoWhistle;

	public static AudioFileDefinition delfalcoBehindJump;

	public static AudioFileDefinition delfalcoPatrolVoice1;

	public static AudioFileDefinition delfalcoPatrolVoice2;

	public static AudioFileDefinition delfalcoPatrolVoice3;

	public static AudioFileDefinition delfalcoPatrolVoice4;

	public static AudioFileDefinition delfalcoJumpA;

	public static AudioFileDefinition delfalcoSawFlesh;

	public static AudioFileDefinition delfalcoSawHit;

	public static AudioFileDefinition delfalcoSawFlip;

	public static AudioFileDefinition delfalcoSawOut;

	public static AudioFileDefinition delfalcoSawSwipe;

	public static AudioFileDefinition delfalcoFall;

	public static AudioFileDefinition delfalcoHit;

	public static AudioFileDefinition delfalcoShh;

	public static AudioFileDefinition ComeCloser;

	public static AudioFileDefinition NotThatClose;

	public static AudioFileDefinition DontMove;

	public static AudioFileDefinition Boo;

	public static AudioFileDefinition NoirLaugh;

	public static AudioFileDefinition MaleNoirJump;

	public static AudioFileDefinition omnom;

	public static AudioFileDefinition nyam;

	public static AudioFileDefinition coffeetime;

	public static AudioFileDefinition welcometothegametwoplus;

	public static AudioFileDefinition newDOSDrainer;

	public static AudioFileDefinition elevatorDing;

	public static AudioFileDefinition elevatorStart;

	public static AudioFileDefinition elevatorBreak;

	public static AudioFileDefinition TheSource;

	public static AudioFileDefinition NothingHere;

	public static AudioFileDefinition KidnapperFootstep1;

	public static AudioFileDefinition KidnapperFootstep2;

	public static AudioFileDefinition KidnapperFootstep3;

	public static AudioFileDefinition KidnapperWarning1;

	public static AudioFileDefinition KidnapperWarning2;

	public static AudioFileDefinition KidnapperWarning3;

	public static AudioFileDefinition LocationServices;

	public static AudioFileDefinition booooom;

	public static AudioClip harbinger;
}
