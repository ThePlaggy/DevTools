using System;

[Serializable]
public enum CARDINAL_DIR
{
	FORWARD,
	BACK,
	LEFT,
	RIGHT
}
