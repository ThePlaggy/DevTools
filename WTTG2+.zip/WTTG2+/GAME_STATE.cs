using System;

[Serializable]
public enum GAME_STATE
{
	LIVE,
	PAUSED
}
