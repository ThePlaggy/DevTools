using System;

[Serializable]
public enum HACK_SWEEPER_SKILL_TIER
{
	INSTABLOCK,
	TIER1,
	TIER2,
	TIER3,
	TIER4,
	TIER5,
	GOD_TIER,
	HACKER_MODE
}
