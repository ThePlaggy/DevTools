using System;

[Serializable]
public enum AFD_TYPE
{
	PLAYER,
	ENEMY,
	COMPUTER,
	OUTSIDE
}
