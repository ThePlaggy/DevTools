using UnityEngine;

public class CultBehaviour : MonoBehaviour
{
	private void Awake()
	{
	}
}
