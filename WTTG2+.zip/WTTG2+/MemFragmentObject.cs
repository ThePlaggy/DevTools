using UnityEngine;

public class MemFragmentObject : MonoBehaviour
{
	public GameObject FragIMG;

	public GameObject HoverIMG;

	public GameObject CorrectIMG;

	public GameObject WrongIMG;

	public GameObject LineIMG;

	public GameObject KeyPart1;

	public GameObject KeyPart2;
}
