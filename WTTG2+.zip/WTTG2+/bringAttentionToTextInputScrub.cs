using UnityEngine;
using UnityEngine.EventSystems;

public class bringAttentionToTextInputScrub : MonoBehaviour, IPointerDownHandler, IEventSystemHandler
{
	public void OnPointerDown(PointerEventData eventData)
	{
	}
}
