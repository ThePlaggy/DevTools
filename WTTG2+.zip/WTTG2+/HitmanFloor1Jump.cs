using UnityEngine;

public class HitmanFloor1Jump : Jump
{
	protected override void DoStage()
	{
		HitmanBehaviour.Ins.GunFlashDoneEvents.Event += EnemyManager.HitManManager.GunFlashGameOver;
		HitmanBehaviour.Ins.ActivateGunMesh();
		HitmanBehaviour.Ins.TriggerAnim("hallDoorJumpIdle");
		HitmanBehaviour.Ins.Spawn(new Vector3(26.749f, 0.021f, -6.315f), new Vector3(0f, -93.07f, 0f));
		HitmanRoamJumper.Ins.TriggerHallWayDoorJump();
		GameManager.TimeSlinger.FireTimer(0.4f, delegate
		{
			GameManager.AudioSlinger.PlaySound(LookUp.SoundLookUp.JumpHit3);
			HitmanBehaviour.Ins.TriggerAnim("hallDoorJump");
		});
	}

	protected override void DoExecute()
	{
		LookUp.Doors.Door8.CancelAutoClose();
	}
}
