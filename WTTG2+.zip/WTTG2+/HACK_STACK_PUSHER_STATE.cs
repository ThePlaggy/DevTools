using System;

[Serializable]
public enum HACK_STACK_PUSHER_STATE
{
	INACTIVE,
	IDLE,
	PUSHER_PLACEMENT,
	PUSHING
}
