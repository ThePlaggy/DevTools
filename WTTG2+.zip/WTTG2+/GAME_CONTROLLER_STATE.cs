using System;

[Serializable]
public enum GAME_CONTROLLER_STATE
{
	LOCKED,
	IDLE,
	WALKING,
	RUNING,
	DUCKING
}
