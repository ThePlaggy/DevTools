public static class ClaffisLookUp
{
	public static AudioFileDefinition[] piano = new AudioFileDefinition[12];

	public static AudioFileDefinition pianoFail;

	public static AudioFileDefinition MysteryPiano;
}
