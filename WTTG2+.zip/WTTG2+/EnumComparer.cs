public static class EnumComparer
{
	public static AudioLayerCompare AudioLayerCompare = new AudioLayerCompare();

	public static AudioHubCompare AudioHubCompare = new AudioHubCompare();

	public static GameControllerCompare GameControllerCompare = new GameControllerCompare();
}
